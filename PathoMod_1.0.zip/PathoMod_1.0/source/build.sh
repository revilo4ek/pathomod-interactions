#!/bin/sh
# Rebuild d3d9.dll (needs gcc with -m32 support, python3). No Windows toolchain required.
FL="-m32 -ffreestanding -fno-pic -fno-stack-protector -fno-asynchronous-unwind-tables -fno-ident -fno-common -O1 -fno-builtin -fno-tree-loop-distribute-patterns -fno-jump-tables -mno-sse -mno-mmx -fno-strict-aliasing -mpreferred-stack-boundary=2"
gcc $FL -c pathomod.c -o pathomod.o && python3 elf2pe.py pathomod.o d3d9.dll d3d9.dll DllMain Direct3DCreate9
