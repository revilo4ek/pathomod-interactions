#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define PM_TAN(x) tanf(x)
#define PM_SQRT(x) sqrtf(x)
#include "core.h"
#include "test_vt.h"
typedef struct { u32 base, size; unsigned char *mem; } Seg;
static Seg segs[4]; static int nseg;
static Seg load_image(const char *file, u32 base) {
    FILE *f = fopen(file, "rb"); fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    unsigned char *d = malloc(n); fread(d, 1, n, f); fclose(f);
    u32 e = *(u32*)(d+0x3c); u32 soi = *(u32*)(d+e+24+56); u16 ns = *(u16*)(d+e+6); u16 os = *(u16*)(d+e+20);
    unsigned char *m = calloc(soi, 1); memcpy(m, d, 0x400);
    for (int i = 0; i < ns; i++) { unsigned char *sh = d+e+24+os+i*40;
        u32 vs=*(u32*)(sh+8), va=*(u32*)(sh+12), rs=*(u32*)(sh+16), ro=*(u32*)(sh+20);
        memcpy(m+va, d+ro, rs < vs ? rs : vs); }
    free(d); Seg s = { base, soi, m }; return s;
}
static int p_read(u32 a, void *dst, u32 len) {
    for (int i = 0; i < nseg; i++)
        if (a >= segs[i].base && (unsigned long)a + len <= (unsigned long)segs[i].base + segs[i].size) { memcpy(dst, segs[i].mem + (a - segs[i].base), len); return 1; }
    return 0;
}
static int region_done; static int region_idx;
#define HEAPSZ 0x400000u
static int p_next_region(u32 *cur, u32 *base, u32 *size) {
    static const u32 RB[2] = {0x30000000u,0x30100000u}, RS[2] = {0x100000u,0x300000u};
    if (*cur <= 0x10000u) region_idx = 0;
    if (region_idx >= 2) return 0;
    *base = RB[region_idx]; *size = RS[region_idx]; *cur = *base + *size; region_idx++; return 1; }
static void p_flush(void) { fwrite(g_log, 1, g_logn, stdout); g_logn = 0; }
static u32 p_tick(void) { return 0; }
static void p_extra(void) {}
static unsigned char *heap;
#define PUT32(addr, v) (*(u32*)(heap + ((addr) - 0x30000000u)) = (u32)(v))
#define PUTF(addr, f)  (*(float*)(heap + ((addr) - 0x30000000u)) = (f))
int main(void) {
    segs[nseg++] = load_image("/home/claude/work/game.exe", 0x400000);
    segs[nseg++] = load_image("/home/claude/work/engine.dll", 0x10000000);
    heap = calloc(1, HEAPSZ); segs[nseg].base = 0x30000000; segs[nseg].size = HEAPSZ; segs[nseg++].mem = heap;
    g_modbase[0] = 0x400000; g_modsize[0] = GAME_SIZE; g_modbase[1] = 0x10000000; g_modsize[1] = ENG_SIZE;
    /* junk: 100k objects of an unrelated engine class placed FIRST in memory (old code would overflow) */
    for (u32 i = 0; i < 100000; i++) PUT32(0x30100000u + i * 8, VT_CInstructionPop);
    float cp[3]={-14852.78f,1717.72f,377.59f}, cf[3]={-0.676f,-0.021f,-0.736f}, cu[3]={-0.014f,0.999f,-0.015f};
    float rr[3]={cu[1]*cf[2]-cu[2]*cf[1], cu[2]*cf[0]-cu[0]*cf[2], cu[0]*cf[1]-cu[1]*cf[0]};
    u32 SCENE=0x152c9a30u, OTHER=0x0b6e670cu;
    /* camera object (game) + world */
    PUT32(0x30010000u, VT_CCameraAttached); PUTF(0x30010024u,1.3963f);
    for(int i=0;i<3;i++){ PUTF(0x30010044u+4*i,cp[i]); PUTF(0x3001005Cu+4*i,cf[i]); PUTF(0x30010068u+4*i,cu[i]); }
    PUT32(0x30011000u, VT_CWorld); PUT32(0x30011038u, SCENE); PUT32(0x30011064u, 0x30010000u); PUT32(0x30011070u, 0x30020000u+4);
    /* active-scene: door (pos @+0x120), npc (pos @+0x98), static outdoor usable (pos @+0x108) */
    PUT32(0x30020000u, VT_CActorDoor);  PUT32(0x30020020u, SCENE);
    for(int i=0;i<3;i++) PUTF(0x30020120u+4*i, cp[i]+cf[i]*300);
    PUT32(0x30021000u, VT_CActorBiped); PUT32(0x30021020u, SCENE);
    for(int i=0;i<3;i++) PUTF(0x30021170u+4*i, cp[i]+cf[i]*500+rr[i]*120);
    PUT32(0x30022000u, VT_CActorStaticOutdoor); PUT32(0x30022020u, SCENE); heap[0x22000+0x105]=1;
    for(int i=0;i<3;i++) PUTF(0x30022108u+4*i, cp[i]+cf[i]*800-rr[i]*150);
    /* a second npc & door so evidence reaches >=2 */
    PUT32(0x30023000u, VT_CActorBiped); PUT32(0x30023020u, SCENE);
    for(int i=0;i<3;i++) PUTF(0x30023170u+4*i, cp[i]+cf[i]*350-rr[i]*60);
    PUT32(0x30024000u, VT_CActorDoor);  PUT32(0x30024020u, SCENE);
    for(int i=0;i<3;i++) PUTF(0x30024120u+4*i, cp[i]+cf[i]*600+rr[i]*200);
    /* other scenes: 700 flagged indoor statics that must be ignored */
    for (u32 i = 0; i < 700; i++) { u32 a = 0x30030000u + i * 0x400; PUT32(a, VT_CActorStaticIndoor); PUT32(a + 0x20, OTHER); heap[(a-0x30000000u)+0x105] = 1; PUTF(a+0x108, 1000.0f+i); PUTF(a+0x10C, -200.0f); PUTF(a+0x110, 500.0f); }
    /* an ACTIVE static placed AFTER the 700 foreign ones (old code stored only the first 255 per class) */
    PUT32(0x30090000u, VT_CActorStaticOutdoor); PUT32(0x30090020u, SCENE); heap[0x90000+0x105]=1;
    for(int i=0;i<3;i++) PUTF(0x30090108u+4*i, cp[i]+cf[i]*400+rr[i]*30);
    g_W=1920; g_H=1080;

    /* ---- reference: synchronous full census ---- */
    census(); find_specials(); hl_build();
    u32 ref_ni=g_ni, ref_nhl=g_nhl, ref_bytes=g_bytes; u32 refaddr[MAXHL]; for(u32 i=0;i<g_nhl;i++) refaddr[i]=g_hl[i].addr;
    printf("REF   sync full : stored=%u entries=%u MB-read=%u hot_regions=%u valid=%u\n",ref_ni,ref_nhl,ref_bytes>>20,g_nhot,g_hot_valid);
    /* ---- time-sliced with a tiny 4 KB budget per step ---- */
    scan_begin(0); u32 steps=0; while(!scan_step(4096)) steps++;
    find_specials(); hl_build();
    int same = (g_ni==ref_ni && g_nhl==ref_nhl); for(u32 i=0;i<g_nhl&&same;i++) if(g_hl[i].addr!=refaddr[i]) same=0;
    printf("SLICE 4KB steps : stored=%u entries=%u steps=%u  identical-to-reference=%d\n",g_ni,g_nhl,steps,same);
    /* ---- odd budget (not multiple of 4, tiny) ---- */
    scan_begin(0); steps=0; while(!scan_step(13)) steps++;
    find_specials(); hl_build();
    same = (g_ni==ref_ni && g_nhl==ref_nhl);
    printf("SLICE 13B steps : stored=%u entries=%u identical=%d\n",g_ni,g_nhl,same);
    /* ---- hot-only rescan ---- */
    scan_begin(1); while(!scan_step(65536)) {}
    find_specials(); hl_build();
    same = (g_nhl==ref_nhl); for(u32 i=0;i<g_nhl&&same;i++) if(g_hl[i].addr!=refaddr[i]) same=0;
    printf("HOT rescan      : entries=%u MB-read=%.2f (full was %u MB) identical-entries=%d\n",g_nhl,g_bytes/1048576.0,ref_bytes>>20,same);
    /* ---- ini parser ---- */
    const char *ini="; comment\r\nhold_key = 0x12   ; Alt\r\nlatch_key=120\r\n[section]\r\nmax_distance_m=25\r\nmarker_size=99\r\nshow_npc=0\r\nshow_static = 0 # no statics\r\ndepth_test=0\r\ndebug=1\r\nbogus=7\r\n  show_door=1\r\n";
    ini_apply(ini,(u32)strlen(ini)); printf("INI debug default=%d (expect 0 before applying)\n",0);
    printf("INI hold=0x%x latch=%d maxdist=%.0f size=%.0f (99 rejected -> default 13) npc=%d door=%d object=%d static=%d depth=%d debug=%d\n",g_cfg.hold_vk,g_cfg.latch_vk,g_cfg.maxdist,g_cfg.size,g_cfg.show[0],g_cfg.show[1],g_cfg.show[2],g_cfg.show[3],g_cfg.depth,g_cfg.debug);
    return 0;
}
