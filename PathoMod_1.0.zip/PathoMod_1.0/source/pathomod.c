/* PathoMod 1.0 - d3d9.dll proxy for Pathologic Classic HD (32-bit).
 * Keys:  TAB (hold) = show markers on usable objects   F9 = latch markers on/off
 *        F6 = debug (grey dots, status squares)        F7 = green test square
 *        F8 = diagnostic dump to pathomod_log.txt      F10 = projection mode (D = exact)   F11 = mirror
 *        INSERT = depth test (hide markers behind walls) on/off;  file pathomod_off.txt = disable everything
 * No imports: kernel32 is located through the PEB, everything else via GetProcAddress.
 */
#define WINAPI __attribute__((stdcall))
#define EXPORT __attribute__((used))
#define PM_VERSION "1.0"

static double f_tan_d(double v) { __asm__ volatile("fptan\n\tfstp %%st(0)" : "+t"(v) : : "st(1)"); return v; }
static double f_sqrt_d(double v) { __asm__ volatile("fsqrt" : "+t"(v)); return v; }
#define PM_TAN(x) ((float)f_tan_d((double)(x)))
#define PM_SQRT(x) ((float)f_sqrt_d((double)(x)))

#include "core.h"

typedef void *HANDLE;

/* ---------- tiny libc replacements (gcc may emit calls to these) ---------- */
EXPORT void *memcpy(void *d, const void *s, u32 n) { u8 *a = d; const u8 *b = s; while (n--) *a++ = *b++; return d; }
EXPORT void *memset(void *d, int c, u32 n) { u8 *a = d; while (n--) *a++ = (u8)c; return d; }

/* ---------- API pointers ---------- */
static void *(WINAPI *f_LoadLibraryA)(const char *);
static void *(WINAPI *f_GetProcAddress)(void *, const char *);
static void *(WINAPI *f_GetModuleHandleA)(const char *);
static u32   (WINAPI *f_GetModuleFileNameA)(void *, char *, u32);
static u32   (WINAPI *f_GetSystemDirectoryA)(char *, u32);
static void *(WINAPI *f_CreateFileA)(const char *, u32, u32, void *, u32, u32, void *);
static int   (WINAPI *f_WriteFile)(void *, const void *, u32, u32 *, void *);
static int   (WINAPI *f_ReadFile)(void *, void *, u32, u32 *, void *);
static u32   (WINAPI *f_GetFileSize)(void *, u32 *);
static int   (WINAPI *f_CloseHandle)(void *);
static u32   (WINAPI *f_VirtualQuery)(const void *, void *, u32);
static int   (WINAPI *f_VirtualProtect)(void *, u32, u32, u32 *);
static int   (WINAPI *f_ReadProcessMemory)(void *, const void *, void *, u32, u32 *);
static u32   (WINAPI *f_GetTickCount)(void);
static short (WINAPI *f_GetAsyncKeyState)(int);

static char g_logpath[300];
static int g_inited;

/* ---------- PEB walk: find kernel32 and its exports ---------- */
static int ci_eq_w(const u16 *w, u32 wlen_bytes, const char *a) {
    u32 n = wlen_bytes / 2, i = 0;
    for (; i < n; i++) {
        u16 c = w[i]; char d = a[i];
        if (!d) return 0;
        if (c >= 'A' && c <= 'Z') c += 32;
        if (d >= 'A' && d <= 'Z') d += 32;
        if (c != (u16)d) return 0;
    }
    return a[i] == 0;
}
static u32 find_module_peb(const char *lname) {
    u32 peb;
    __asm__ volatile("movl %%fs:0x30, %0" : "=r"(peb));
    u32 ldr = *(u32 *)(peb + 0x0C);
    u32 head = ldr + 0x14;
    for (u32 cur = *(u32 *)head; cur != head && cur; cur = *(u32 *)cur) {
        u16 len = *(u16 *)(cur + 0x24);
        const u16 *name = *(const u16 **)(cur + 0x28);
        if (name && ci_eq_w(name, len, lname)) return *(u32 *)(cur + 0x10);
    }
    return 0;
}
static int cstr_eq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static void *find_export(u32 base, const char *name) {
    u32 e = *(u32 *)(base + 0x3c);
    u32 exp_rva = *(u32 *)(base + e + 24 + 96), exp_sz = *(u32 *)(base + e + 24 + 100);
    if (!exp_rva) return 0;
    u32 ex = base + exp_rva;
    u32 nnames = *(u32 *)(ex + 24);
    const u32 *names = (const u32 *)(base + *(u32 *)(ex + 32));
    const u16 *ords = (const u16 *)(base + *(u32 *)(ex + 36));
    const u32 *funcs = (const u32 *)(base + *(u32 *)(ex + 28));
    for (u32 i = 0; i < nnames; i++) {
        if (cstr_eq((const char *)(base + names[i]), name)) {
            u32 rva = funcs[ords[i]];
            if (rva >= exp_rva && rva < exp_rva + exp_sz) return 0;   /* forwarder: not handled */
            return (void *)(base + rva);
        }
    }
    return 0;
}

#define RESOLVE(var, name) do { *(void **)&var = f_GetProcAddress(k32h, name); } while (0)

static int init_apis(void) {
    u32 k32 = find_module_peb("kernel32.dll");
    if (!k32) return 0;
    *(void **)&f_LoadLibraryA = find_export(k32, "LoadLibraryA");
    *(void **)&f_GetProcAddress = find_export(k32, "GetProcAddress");
    if (!f_LoadLibraryA || !f_GetProcAddress) return 0;
    void *k32h = (void *)k32;
    RESOLVE(f_GetModuleHandleA, "GetModuleHandleA");
    RESOLVE(f_GetModuleFileNameA, "GetModuleFileNameA");
    RESOLVE(f_GetSystemDirectoryA, "GetSystemDirectoryA");
    RESOLVE(f_CreateFileA, "CreateFileA");
    RESOLVE(f_WriteFile, "WriteFile");
    RESOLVE(f_ReadFile, "ReadFile");
    RESOLVE(f_GetFileSize, "GetFileSize");
    RESOLVE(f_CloseHandle, "CloseHandle");
    RESOLVE(f_VirtualQuery, "VirtualQuery");
    RESOLVE(f_VirtualProtect, "VirtualProtect");
    RESOLVE(f_ReadProcessMemory, "ReadProcessMemory");
    RESOLVE(f_GetTickCount, "GetTickCount");
    void *u32h = f_LoadLibraryA("user32.dll");
    if (u32h) *(void **)&f_GetAsyncKeyState = f_GetProcAddress(u32h, "GetAsyncKeyState");
    return f_GetModuleHandleA && f_GetModuleFileNameA && f_GetSystemDirectoryA && f_CreateFileA &&
           f_WriteFile && f_CloseHandle && f_VirtualQuery && f_VirtualProtect && f_ReadProcessMemory;
}

/* ---------- platform functions for core.h ---------- */
static int p_read(u32 addr, void *dst, u32 len) {
    u32 got = 0;
    if (!f_ReadProcessMemory) return 0;
    if (!f_ReadProcessMemory((void *)-1, (const void *)addr, dst, len, &got)) return 0;
    return got == len;
}
static int p_next_region(u32 *cur, u32 *base, u32 *size) {
    struct { u32 BaseAddress, AllocationBase, AllocationProtect, RegionSize, State, Protect, Type; } m;
    while (*cur < 0x7FFF0000u) {
        if (!f_VirtualQuery((const void *)*cur, &m, sizeof m)) return 0;
        u32 b = m.BaseAddress, s = m.RegionSize;
        u32 next = b + s;
        *cur = (next <= b) ? 0x7FFF0000u : next;
        if (m.State == 0x1000 && m.Type == 0x20000 && (m.Protect & (0x04 | 0x08 | 0x40 | 0x80)) && !(m.Protect & (0x01 | 0x100))) {
            if (b + s > 0x7FFF0000u) s = 0x7FFF0000u - b;
            *base = b; *size = s;
            return 1;
        }
    }
    return 0;
}
static void p_flush(void) {
    if (g_logn && f_CreateFileA && g_logpath[0]) {
        void *h = f_CreateFileA(g_logpath, 0x00000004 /*FILE_APPEND_DATA*/, 3, 0, 4 /*OPEN_ALWAYS*/, 0x80, 0);
        if (h != (void *)-1 && h) { u32 w; f_WriteFile(h, g_log, g_logn, &w, 0); f_CloseHandle(h); }
    }
    g_logn = 0;
}
static u32 p_tick(void) { return f_GetTickCount ? f_GetTickCount() : 0; }

/* ---------- D3D9 COM helpers (vtable indices of IDirect3D9 / IDirect3DDevice9) ---------- */
#define VT(o) (*(void ***)(o))
#define IDX_RELEASE 2
static void com_release(void *o) { if (o) ((u32 (WINAPI *)(void *))VT(o)[IDX_RELEASE])(o); }

static i32 d_GetBackBuffer(void *d, u32 sw, u32 i, u32 t, void **o) { return ((i32 (WINAPI *)(void *, u32, u32, u32, void **))VT(d)[18])(d, sw, i, t, o); }
static i32 d_GetRenderTarget(void *d, u32 i, void **o) { return ((i32 (WINAPI *)(void *, u32, void **))VT(d)[38])(d, i, o); }
static i32 d_SetRenderTarget(void *d, u32 i, void *s) { return ((i32 (WINAPI *)(void *, u32, void *))VT(d)[37])(d, i, s); }
static i32 d_BeginScene(void *d) { return ((i32 (WINAPI *)(void *))VT(d)[41])(d); }
static i32 d_EndScene(void *d) { return ((i32 (WINAPI *)(void *))VT(d)[42])(d); }
static i32 d_SetViewport(void *d, const void *vp) { return ((i32 (WINAPI *)(void *, const void *))VT(d)[47])(d, vp); }
static i32 d_SetRenderState(void *d, u32 s, u32 v) { return ((i32 (WINAPI *)(void *, u32, u32))VT(d)[57])(d, s, v); }
static i32 d_CreateStateBlock(void *d, u32 t, void **o) { return ((i32 (WINAPI *)(void *, u32, void **))VT(d)[59])(d, t, o); }
static i32 d_SetTexture(void *d, u32 s, void *t) { return ((i32 (WINAPI *)(void *, u32, void *))VT(d)[65])(d, s, t); }
static i32 d_SetTextureStageState(void *d, u32 s, u32 t, u32 v) { return ((i32 (WINAPI *)(void *, u32, u32, u32))VT(d)[67])(d, s, t, v); }
static i32 d_DrawPrimitiveUP(void *d, u32 pt, u32 n, const void *v, u32 stride) { return ((i32 (WINAPI *)(void *, u32, u32, const void *, u32))VT(d)[83])(d, pt, n, v, stride); }
static i32 d_SetFVF(void *d, u32 f) { return ((i32 (WINAPI *)(void *, u32))VT(d)[89])(d, f); }
static i32 d_SetVertexShader(void *d, void *s) { return ((i32 (WINAPI *)(void *, void *))VT(d)[92])(d, s); }
static i32 d_SetPixelShader(void *d, void *s) { return ((i32 (WINAPI *)(void *, void *))VT(d)[107])(d, s); }
static i32 sb_Capture(void *s) { return ((i32 (WINAPI *)(void *))VT(s)[4])(s); }
static i32 sb_Apply(void *s) { return ((i32 (WINAPI *)(void *))VT(s)[5])(s); }
static i32 surf_GetDesc(void *s, u32 *desc) { return ((i32 (WINAPI *)(void *, u32 *))VT(s)[12])(s, desc); }

typedef struct { float x, y, z, rhw; u32 col; } Vtx;
#define MAXV 12000
static Vtx g_tri[MAXV];
static u32 g_ntri;

static int g_marker, g_latch, g_tab, g_dbg, g_mode = 3, g_mirror, g_dirty = 1, g_depth = 1, g_off;
static u32 g_last_scan, g_last_full, g_retry_at, g_frame, g_rr, g_in_present;
static int g_ever, g_fp_bad, g_fp_logged;
static u32 g_vp_raw[16]; static int g_vp_ok;

static float g_curz;
static void v_tri(float x0, float y0, float x1, float y1, float x2, float y2, u32 c) {
    if (g_ntri + 3 > MAXV) return;
    Vtx *v = &g_tri[g_ntri];
    v[0].x = x0; v[0].y = y0; v[1].x = x1; v[1].y = y1; v[2].x = x2; v[2].y = y2;
    for (int i = 0; i < 3; i++) { v[i].z = g_curz; v[i].rhw = 1; v[i].col = c; }
    g_ntri += 3;
}
static void v_rect(float x0, float y0, float x1, float y1, u32 c) {
    v_tri(x0, y0, x1, y0, x0, y1, c); v_tri(x1, y0, x1, y1, x0, y1, c);
}
static void v_line(float x0, float y0, float x1, float y1, float w, u32 c) {
    float dx = x1 - x0, dy = y1 - y0, l = PM_SQRT(dx * dx + dy * dy);
    if (l < 0.5f) return;
    float nx = -dy / l * w * 0.5f, ny = dx / l * w * 0.5f;
    v_tri(x0 + nx, y0 + ny, x1 + nx, y1 + ny, x0 - nx, y0 - ny, c);
    v_tri(x1 + nx, y1 + ny, x1 - nx, y1 - ny, x0 - nx, y0 - ny, c);
}
static void v_diamond(float cx, float cy, float r, u32 fill, u32 edge) {
    v_tri(cx, cy - r, cx + r, cy, cx, cy + r, fill);
    v_tri(cx, cy - r, cx, cy + r, cx - r, cy, fill);
    v_line(cx, cy - r, cx + r, cy, 2.5f, edge); v_line(cx + r, cy, cx, cy + r, 2.5f, edge);
    v_line(cx, cy + r, cx - r, cy, 2.5f, edge); v_line(cx - r, cy, cx, cy - r, 2.5f, edge);
    v_rect(cx - 2, cy - 2, cx + 2, cy + 2, edge);
}

static int visible_now(void) { return g_latch || g_tab; }

static void build_overlay(float W, float H) {
    g_ntri = 0; g_curz = 0.0f;
    if (g_marker) v_rect(8, 8, 40, 40, 0xC000FF00u);
    if (!visible_now()) return;
    static const u32 mc[4] = { 0xFFFF3030u, 0xFF30FF30u, 0xFF3080FFu, 0xFFFF40FFu };
    if (g_dbg) {
        v_rect(8, 48, 24, 64, mc[g_mode]);
        v_rect(30, 48, 46, 64, g_mirror ? 0xFFFFFFFFu : 0xFF404040u);
        v_rect(52, 48, 68, 64, 0xFFFFFF00u);
    }
    if (g_fp_bad) { v_rect(8, 72, 20, 84, 0xFFFF0000u); v_rect(24, 72, 36, 84, 0xFFFF0000u); v_rect(40, 72, 52, 84, 0xFFFF0000u); return; }
    if (g_sc_state) v_rect(8, 72, 20, 84, 0xFFFFA000u);        /* amber square: scanning in background */
    Cam cam;
    if (!get_camera(&cam)) { v_rect(8, 48, 24, 64, 0xFFFF0000u); return; }
    u32 sel = 0;
    if (g_s_world) p_read(g_s_world + 0x70, &sel, 4);
    /* NPC cyan, door orange, object green, static green; selected yellow */
    static const u32 fillc[4] = { 0x6040E0FFu, 0x60FFA020u, 0x6000FF00u, 0x6000FF00u };
    static const u32 edgec[4] = { 0xFF40E0FFu, 0xFFFFA020u, 0xFF00FF00u, 0xFF00FF00u };
    for (u32 i = 0; i < g_nhl; i++) {
        HLE *e = &g_hl[i];
        if (!e->valid) continue;
        if (!e->usable && !g_dbg) continue;
        if (!g_cfg.show[e->grp]) continue;
        float sx, sy, vz;
        if (!project(&cam, e->pos, W, H, g_mode, g_mirror, &sx, &sy, &vz)) continue;
        if (sx < -60 || sx > W + 60 || sy < -60 || sy > H + 60) continue;
        int isel = sel && sel == e->addr + 4;
        if (!e->usable) { v_rect(sx - 2, sy - 2, sx + 2, sy + 2, 0xC0A0A0A0u); continue; }
        if (vz > g_cfg.maxdist && !isel) continue;
        float r = isel ? g_cfg.size * 1.5f : g_cfg.size;
        { float bias = 60.0f + 0.04f * vz; g_curz = proj_z(vz - bias); }      /* pull the marker toward the camera */
        if (isel) v_diamond(sx, sy, r, 0x70FFE000u, 0xFFFFE000u);
        else v_diamond(sx, sy, r, fillc[e->grp], edgec[e->grp]);
    }
    g_curz = 0.0f;
}

static int get_wh(void *dev) {
    void *bb = 0; u32 desc[8];
    if (d_GetBackBuffer(dev, 0, 0, 0, &bb) < 0 || !bb) return 0;
    desc[6] = desc[7] = 0;
    surf_GetDesc(bb, desc);
    com_release(bb);
    if (!desc[6] || !desc[7]) return 0;
    g_W = desc[6]; g_H = desc[7];
    return 1;
}

static void render_overlay(void *dev) {
    void *rt = 0, *bb = 0, *sb = 0;
    u32 desc[8];
    if (d_GetBackBuffer(dev, 0, 0, 0, &bb) < 0 || !bb) return;
    d_GetRenderTarget(dev, 0, &rt);
    desc[6] = desc[7] = 0;
    surf_GetDesc(bb, desc);
    u32 W = desc[6], H = desc[7];
    g_W = W; g_H = H;
    if (!W || !H) { com_release(rt); com_release(bb); return; }
    build_overlay((float)W, (float)H);
    if (g_ntri) {
        if (d_CreateStateBlock(dev, 1 /*D3DSBT_ALL*/, &sb) < 0 || !sb) { com_release(rt); com_release(bb); return; }
        sb_Capture(sb);
        d_SetRenderTarget(dev, 0, bb);
        u32 vp[6] = { 0, 0, W, H, 0, 0x3f800000u };
        d_SetViewport(dev, vp);
        if (d_BeginScene(dev) >= 0) {
            d_SetVertexShader(dev, 0); d_SetPixelShader(dev, 0); d_SetFVF(dev, 0x44 /*XYZRHW|DIFFUSE*/); d_SetTexture(dev, 0, 0);
            d_SetRenderState(dev, 7, g_depth ? 1 : 0); d_SetRenderState(dev, 23, 4 /*LESSEQUAL*/); d_SetRenderState(dev, 14, 0);  d_SetRenderState(dev, 15, 0);
            d_SetRenderState(dev, 19, 5);  d_SetRenderState(dev, 20, 6);  d_SetRenderState(dev, 22, 1);
            d_SetRenderState(dev, 27, 1);  d_SetRenderState(dev, 28, 0);  d_SetRenderState(dev, 52, 0);
            d_SetRenderState(dev, 137, 0); d_SetRenderState(dev, 174, 0); d_SetRenderState(dev, 168, 15);
            d_SetRenderState(dev, 8, 3);   d_SetRenderState(dev, 206, 0); d_SetRenderState(dev, 194, 0);
            d_SetTextureStageState(dev, 0, 1, 2); d_SetTextureStageState(dev, 0, 2, 0);
            d_SetTextureStageState(dev, 0, 4, 2); d_SetTextureStageState(dev, 0, 5, 0);
            d_SetTextureStageState(dev, 1, 1, 1);
            d_DrawPrimitiveUP(dev, 4 /*TRIANGLELIST*/, g_ntri / 3, g_tri, sizeof(Vtx));
            d_EndScene(dev);
        }
        sb_Apply(sb);
        if (rt) d_SetRenderTarget(dev, 0, rt);
        com_release(sb);
    }
    com_release(rt); com_release(bb);
}

/* ---------- vertex shader constant capture (diagnostic + projection self-check) ---------- */
#define VSC_MAX 128
typedef struct { u32 start, count; u32 d[32]; } Vsc;
static Vsc g_vc[VSC_MAX], g_vpv[VSC_MAX];
static u32 g_vcn, g_vpn, g_vh[1024], g_orig_vscf;

static i32 WINAPI HkSetVSCF(void *dev, u32 start, const u32 *data, u32 count) {
    if (data && !g_in_present) {
        if (start == 0 && count >= 16) { for (int i = 0; i < 16; i++) g_vp_raw[i] = data[i]; g_vp_ok = 1; }
        if (count >= 4 && start < 64 && g_vcn < VSC_MAX) {
            u32 n = count > 8 ? 8 : count, words = n * 4, h = 2166136261u ^ start;
            for (u32 i = 0; i < words; i++) h = (h ^ data[i]) * 16777619u;
            h |= 1;
            u32 k = h & 1023; int dup = 0;
            while (g_vh[k]) { if (g_vh[k] == h) { dup = 1; break; } k = (k + 1) & 1023; }
            if (!dup) {
                g_vh[k] = h;
                Vsc *e = &g_vc[g_vcn++];
                e->start = start; e->count = count;
                for (u32 i = 0; i < words; i++) e->d[i] = data[i];
            }
        }
    }
    return ((i32 (WINAPI *)(void *, u32, const u32 *, u32))g_orig_vscf)(dev, start, data, count);
}
static void vsc_swap(void) {
    if (g_vcn) { memcpy(g_vpv, g_vc, g_vcn * sizeof(Vsc)); g_vpn = g_vcn; }
    g_vcn = 0;
    memset(g_vh, 0, sizeof g_vh);
}
static void p_extra(void) {
    ls("\n--- VERTEX SHADER CONSTANTS (unique blocks, previous frame) n="); ldec(g_vpn); lnl();
    for (u32 i = 0; i < g_vpn; i++) {
        u32 words = (g_vpv[i].count > 8 ? 8 : g_vpv[i].count) * 4;
        ls("VSC "); ldec(g_vpv[i].start); ls("+"); ldec(g_vpv[i].count); ls(":");
        for (u32 j = 0; j < words; j++) { lc(' '); lhex(g_vpv[i].d[j], 8); }
        lnl();
    }
}

/* ---------- hooks ---------- */
static u32 g_orig_create, g_orig_present;
static int g_prev[8], g_first_present;

static int hook_slot(void **vt, int idx, void *fn, u32 *orig) {
    u32 old;
    if (!f_VirtualProtect(&vt[idx], 4, 0x40, &old)) return 0;
    if (!*orig) *orig = (u32)vt[idx];
    vt[idx] = fn;
    f_VirtualProtect(&vt[idx], 4, old, &old);
    return 1;
}

static void refresh_modules(void) {
    g_modbase[0] = (u32)f_GetModuleHandleA(0);
    g_modbase[1] = (u32)f_GetModuleHandleA("Engine.dll");
    g_modbase[2] = (u32)f_GetModuleHandleA("D3D.dll");
    g_modsize[0] = GAME_SIZE; g_modsize[1] = ENG_SIZE; g_modsize[2] = D3D_SIZE;
    for (int i = 0; i < 3; i++) if (!g_modbase[i]) g_modsize[i] = 0;
}

static void log_scan_summary(void) {
    static const char *const gn[4] = { "npc", "door", "object", "static" };
    ls("  active scene=0x"); lhex(g_scene, 8); ls(" entries="); ldec(g_nhl);
    u32 cnt[NK], usable[NK], withpos[NK];
    for (int k = 0; k < NK; k++) cnt[k] = usable[k] = withpos[k] = 0;
    for (u32 i = 0; i < g_nhl; i++) { cnt[g_hl[i].kc]++; if (g_hl[i].usable) usable[g_hl[i].kc]++; if (g_hl[i].valid) withpos[g_hl[i].kc]++; }
    lnl();
    for (int k = 0; k < NK; k++) if (cnt[k]) {
        ls("   "); ls(K_NAME[k]); ls(" ["); ls(gn[K_GRP[k]]); ls("]: active="); ldec(cnt[k]); ls(" usable="); ldec(usable[k]);
        ls(" pos_known="); ldec(withpos[k]); ls(" posoff=");
        if (g_posoff[k]) { ls("0x"); lhex(g_posoff[k], 3); } else ls("?");
        u32 best = 0, bo = 0;
        for (u32 q = 0; q <= 0xC0; q++) if (g_ev[k][q] > best) { best = g_ev[k][q]; bo = q * 4; }
        ls(" best-evidence=");
        if (best) { ls("+0x"); lhex(bo, 3); ls("x"); ldec(best); } else ls("none");
        lnl();
    }
    Cam cam;
    if (!get_camera(&cam)) { ls("  camera unreadable\n"); }
    else {
        ls("  camera pos="); lvec(cam.pos); ls(" fov="); lfloat(cam.fov); ls(" window="); ldec(g_W); ls("x"); ldec(g_H); lnl();
        if (g_vp_ok && g_W) {   /* compare with the game's own matrix: rows 0..3 as clip = M * [pos,1] */
            const float *m = (const float *)g_vp_raw;
            float sxm = PM_SQRT(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]) / PM_SQRT(m[12] * m[12] + m[13] * m[13] + m[14] * m[14]);
            float sym = PM_SQRT(m[4] * m[4] + m[5] * m[5] + m[6] * m[6]) / PM_SQRT(m[12] * m[12] + m[13] * m[13] + m[14] * m[14]);
            float t = PM_TAN(cam.fov * 0.5f) * 0.75f;
            ls("  matrix scale sx="); lfloat(sxm); ls(" sy="); lfloat(sym);
            ls("  formula sx="); lfloat(1.0f / (t * (float)g_W / (float)g_H)); ls(" sy="); lfloat(1.0f / t); lnl();
        }
    }
    p_flush();
}

static void scan_start(void *dev, int mode) {
    refresh_modules();
    get_wh(dev);
    if (!check_module(0, GAME_TS, GAME_SIZE) || !check_module(1, ENG_TS, ENG_SIZE)) {
        g_fp_bad = 1;
        if (!g_fp_logged) { g_fp_logged = 1; ls("game version does not match the tables this mod was built for - scanning disabled\\n"); p_flush(); }
        return;
    }
    g_fp_bad = 0;
    scan_begin(mode);
    g_ever = 1;
}

static void scan_done(void) {
    u32 now = p_tick();
    find_specials();
    hl_build();
    g_last_scan = now;
    if (g_sc_mode == 0) g_last_full = now;
    if (!g_s_world) { g_dirty = 1; g_retry_at = now + 5000u; } else g_dirty = 0;
    ls(g_sc_mode ? "scan(hot): " : "scan(full): "); ls("ms="); ldec(now - g_sc_t0); ls(" regions="); ldec(g_regions);
    ls(" MB="); ldec(g_bytes >> 20); ls(" stored="); ldec(g_ni); ls(" overflow="); ldec(g_nover);
    ls(" hot="); ldec(g_nhot); ls(" world=0x"); lhex(g_s_world, 8); lnl();
    log_scan_summary();
}

/* decides whether to (re)scan and advances a running scan by a small budget each frame */
static void scan_tick(void *dev) {
    u32 now = p_tick();
    if (g_sc_state) {
        if (scan_step(visible_now() ? (4u << 20) : (3u << 19))) scan_done();
        return;
    }
    if (g_fp_bad) return;
    if (g_dirty && now >= g_retry_at && (visible_now() || (g_ever && g_s_world))) { scan_start(dev, 0); return; }
    if (!g_dirty && visible_now() && now - g_last_scan > 30000u) {
        int hot = g_hot_valid && g_nhot && (now - g_last_full < 300000u);
        scan_start(dev, hot ? 1 : 0);
    }
}

static void load_config(void) {
    static char path[300], buf[4096];
    u32 n = 0; while (g_logpath[n]) n++;
    while (n && g_logpath[n - 1] != '\\') n--;
    for (u32 i = 0; i < n; i++) path[i] = g_logpath[i];
    const char *nm = "pathomod.ini";
    for (u32 i = 0; nm[i]; i++) path[n + i] = nm[i];
    path[n + 12] = 0;
    void *h = f_CreateFileA(path, 0x80000000u, 7, 0, 3 /*OPEN_EXISTING*/, 0x80, 0);
    if (h && h != (void *)-1) {
        u32 got = 0;
        if (f_ReadFile && f_ReadFile(h, buf, sizeof buf - 1, &got, 0)) ini_apply(buf, got);
        f_CloseHandle(h);
        ls("config: pathomod.ini loaded\n");
    } else {
        static const char def[] =
            "; PathoMod settings. Delete this file to restore defaults. Key codes: decimal or 0x hex (VK codes).\r\n"
            "hold_key=0x09          ; hold to show markers (0x09 = Tab)\r\n"
            "latch_key=0x78         ; toggle markers on/off (0x78 = F9)\r\n"
            "depth_key=0x2D         ; toggle hiding markers behind walls (0x2D = Insert)\r\n"
            "max_distance_m=40      ; do not show markers farther than this (meters)\r\n"
            "marker_size=13         ; marker radius in pixels\r\n"
            "depth_test=1           ; 1 = hide markers behind walls\r\n"
            "show_npc=1\r\nshow_door=1\r\nshow_object=1\r\nshow_static=1\r\n"
            "debug=0               ; 1 = enable developer keys (F6/F7/F8/F10/F11) and detailed diagnostics\r\n";
        void *w = f_CreateFileA(path, 0x40000000u, 3, 0, 1 /*CREATE_NEW*/, 0x80, 0);
        if (w && w != (void *)-1) { u32 wr; f_WriteFile(w, def, sizeof def - 1, &wr, 0); f_CloseHandle(w); ls("config: default pathomod.ini created\n"); }
    }
    g_depth = g_cfg.depth;
}

static i32 WINAPI HkPresent(void *dev, const void *a, const void *b, void *c, const void *d) {
    if (!g_in_present) {
        g_in_present = 1;
        g_frame++;
        vsc_swap();
        if (!g_first_present) {
            g_first_present = 1;
            ls("first Present() through hook, device=0x"); lhex((u32)dev, 8); lnl(); p_flush();
        }
        if (f_GetAsyncKeyState) {
            int keys[8] = { 0x75, 0x76, 0x77, g_cfg.latch_vk, 0x79, 0x7A, g_cfg.hold_vk, g_cfg.depth_vk };   /* F6,F7,F8,latch,F10,F11,hold,depth */
            int k[8];
            for (int i = 0; i < 8; i++) k[i] = (f_GetAsyncKeyState(keys[i]) & 0x8000) != 0;
            if (g_cfg.debug && k[0] && !g_prev[0]) { g_dbg = !g_dbg; ls("debug "); ls(g_dbg ? "ON" : "OFF"); lnl(); p_flush(); }
            if (g_cfg.debug && k[1] && !g_prev[1]) { g_marker = !g_marker; ls("marker "); ls(g_marker ? "ON" : "OFF"); lnl(); p_flush(); }
            if (g_cfg.debug && k[2] && !g_prev[2]) { get_wh(dev); refresh_modules(); pm_dump(); }
            if (k[3] && !g_prev[3]) { g_latch = !g_latch; ls("latch "); ls(g_latch ? "ON" : "OFF"); lnl(); if (g_latch) hl_relearn(); else p_flush(); }
            if (g_cfg.debug && k[4] && !g_prev[4]) { g_mode = (g_mode + 1) % 4; ls("mode="); lc((char)('A' + g_mode)); lnl(); p_flush(); }
            if (g_cfg.debug && k[5] && !g_prev[5]) { g_mirror = !g_mirror; ls("mirror="); ldec((u32)g_mirror); lnl(); p_flush(); }
            if (k[6] && !g_prev[6]) { g_tab = 1; hl_relearn(); }
            if (!k[6] && g_prev[6]) g_tab = 0;
            if (k[7] && !g_prev[7]) { g_depth = !g_depth; ls("depth test "); ls(g_depth ? "ON" : "OFF"); lnl(); p_flush(); }
            for (int i = 0; i < 8; i++) g_prev[i] = k[i];
        }
        scan_tick(dev);
        /* cheap staleness check every 30 frames: world still alive, scene unchanged */
        if ((g_frame % 30) == 0 && g_s_world && !g_dirty) {
            if (!world_valid() || scene_now() != g_scene) { g_dirty = 1; g_nhl = 0; }   /* hide stale markers until the rescan finishes */
        }
        /* refresh a slice of the entries every frame while markers are shown */
        if (visible_now() && g_nhl) {
            u32 n = g_nhl, step = (n + 7) / 8, i0 = g_rr;
            for (u32 i = 0; i < step; i++) hl_refresh(&g_hl[(i0 + i) % n]);
            g_rr = (i0 + step) % n;
        }
        if (g_marker || visible_now()) render_overlay(dev);
        g_in_present = 0;
    }
    return ((i32 (WINAPI *)(void *, const void *, const void *, void *, const void *))g_orig_present)(dev, a, b, c, d);
}

static i32 WINAPI HkCreateDevice(void *self, u32 adapter, u32 type, void *hwnd, u32 flags, void *pp, void **ppdev) {
    i32 hr = ((i32 (WINAPI *)(void *, u32, u32, void *, u32, void *, void **))g_orig_create)(self, adapter, type, hwnd, flags, pp, ppdev);
    ls("CreateDevice hr=0x"); lhex((u32)hr, 8); ls(" adapter="); ldec(adapter); ls(" type="); ldec(type);
    if (hr >= 0 && ppdev && *ppdev) {
        void **vt = VT(*ppdev);
        ls(" device=0x"); lhex((u32)*ppdev, 8); ls(" Present@0x"); lhex((u32)vt[17], 8);
        if (vt[17] != (void *)HkPresent) ls(hook_slot(vt, 17, (void *)HkPresent, &g_orig_present) ? " -> hooked" : " -> HOOK FAILED");
        if (vt[94] != (void *)HkSetVSCF) ls(hook_slot(vt, 94, (void *)HkSetVSCF, &g_orig_vscf) ? " vsc-hooked" : " VSC HOOK FAILED");
    }
    lnl(); p_flush();
    return hr;
}

/* ---------- exported proxy ---------- */
static void *(WINAPI *real_create)(u32);

EXPORT void *WINAPI Direct3DCreate9(u32 ver) {
    if (!g_inited) {
        g_inited = 1;
        if (!init_apis()) return 0;
        u32 n = f_GetModuleFileNameA(0, g_logpath, 280);
        while (n && g_logpath[n - 1] != '\\') n--;
        const char *fn = "pathomod_log.txt";
        for (u32 i = 0; fn[i]; i++) g_logpath[n + i] = fn[i];
        g_logpath[n + 16] = 0;
        if (f_GetFileSize) {   /* keep the log from growing forever: start fresh when it exceeds 2 MB */
            void *lh = f_CreateFileA(g_logpath, 0x80000000u, 7, 0, 3 /*OPEN_EXISTING*/, 0x80, 0);
            if (lh && lh != (void *)-1) {
                u32 sz = f_GetFileSize(lh, 0); f_CloseHandle(lh);
                if (sz != 0xFFFFFFFFu && sz > (2u << 20)) { void *t = f_CreateFileA(g_logpath, 0x40000000u, 3, 0, 2 /*CREATE_ALWAYS*/, 0x80, 0); if (t && t != (void *)-1) f_CloseHandle(t); }
            }
        }
        ls("\n##### PathoMod " PM_VERSION " loaded (d3d9 proxy) #####\n");
        load_config();
        {   /* kill switch: if pathomod_off.txt exists, behave as a pure pass-through */
            char off[300]; u32 i = 0; while (g_logpath[i]) { off[i] = g_logpath[i]; i++; }
            const char *nm = "pathomod_off.txt"; u32 j = n;
            for (u32 q = 0; nm[q]; q++) off[j + q] = nm[q];
            off[j + 16] = 0;
            void *h = f_CreateFileA(off, 0x80000000u, 7, 0, 3 /*OPEN_EXISTING*/, 0x80, 0);
            if (h && h != (void *)-1) { f_CloseHandle(h); g_off = 1; ls("pathomod_off.txt found: hooks DISABLED (pass-through)\n"); }
        }
        char sys[300]; u32 sl = f_GetSystemDirectoryA(sys, 270);
        const char *tail = "\\d3d9.dll";
        for (u32 i = 0; tail[i]; i++) sys[sl + i] = tail[i];
        sys[sl + 9] = 0;
        void *h = f_LoadLibraryA(sys);
        if (h) *(void **)&real_create = f_GetProcAddress(h, "Direct3DCreate9");
        ls("real d3d9: "); ls(sys); ls(real_create ? " OK" : " FAILED"); lnl(); p_flush();
    }
    if (!real_create) return 0;
    void *d3d = real_create(ver);
    if (d3d) {
        void **vt = VT(d3d);
        ls("Direct3DCreate9("); ldec(ver); ls(") -> 0x"); lhex((u32)d3d, 8);
        if (!g_off && vt[16] != (void *)HkCreateDevice) ls(hook_slot(vt, 16, (void *)HkCreateDevice, &g_orig_create) ? " CreateDevice hooked" : " HOOK FAILED");
        lnl(); p_flush();
    }
    return d3d;
}

EXPORT int WINAPI DllMain(void *h, u32 reason, void *res) { (void)h; (void)reason; (void)res; return 1; }
