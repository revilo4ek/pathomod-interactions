#!/usr/bin/env python3
"""
elf2pe.py - minimal linker: one ELF32 i386 relocatable object -> PE32 DLL.

Limitations (by design):
  * single input object, no imports (code must resolve APIs itself)
  * supports R_386_32, R_386_PC32, R_386_PLT32
  * exports listed on the command line (by symbol name)
Usage: elf2pe.py in.o out.dll DllName.dll Entry Export1 [Export2 ...]
"""
import struct, sys, time

IMAGE_BASE = 0x6A3E0000
SEC_ALIGN = 0x1000
FILE_ALIGN = 0x200
HDR_SIZE = 0x400

def align(x, a): return (x + a - 1) // a * a

def main():
    inp, outp, dllname, entry = sys.argv[1:5]
    exports = sys.argv[5:]
    d = open(inp, 'rb').read()
    assert d[:4] == b'\x7fELF' and d[4] == 1 and d[5] == 1, 'need ELF32 LE'
    e_shoff, = struct.unpack_from('<I', d, 0x20)
    e_shentsize, e_shnum, e_shstrndx = struct.unpack_from('<HHH', d, 0x2e)
    secs = []
    for i in range(e_shnum):
        n, t, f, a, o, s, l, inf, al, es = struct.unpack_from('<10I', d, e_shoff + i * e_shentsize)
        secs.append(dict(i=i, name_off=n, type=t, flags=f, off=o, size=s, link=l, info=inf, align=max(al, 1), entsize=es))
    shstr = secs[e_shstrndx]
    def cstr(tab, off):
        o = tab['off'] + off
        return d[o:d.index(b'\0', o)].decode('latin1')
    for s in secs: s['name'] = cstr(shstr, s['name_off'])

    symtab = next(s for s in secs if s['type'] == 2)
    strtab = secs[symtab['link']]
    syms = []
    for k in range(symtab['size'] // 16):
        n, v, sz, info, other, shndx = struct.unpack_from('<IIIBBH', d, symtab['off'] + k * 16)
        syms.append(dict(name=cstr(strtab, n), value=v, size=sz, bind=info >> 4, type=info & 15, shndx=shndx))

    # ---- layout of allocatable sections into 3 PE sections
    groups = {'.text': [], '.rdata': [], '.data': [], '.bss': []}
    for s in secs:
        if not (s['flags'] & 2) or s['size'] == 0 and s['type'] != 8:  # SHF_ALLOC
            if not (s['flags'] & 2): continue
        if s['type'] == 8: groups['.bss'].append(s)
        elif s['flags'] & 4: groups['.text'].append(s)
        elif s['flags'] & 1: groups['.data'].append(s)
        else: groups['.rdata'].append(s)

    pe_secs = {}   # name -> dict(rva, vsize, data(bytearray), chars)
    cur_rva = SEC_ALIGN
    layout = {}    # elf section index -> (pe section name, offset within)
    def build(name, lst, chars, extra_bss=None):
        nonlocal cur_rva
        buf = bytearray()
        for s in lst:
            buf.extend(b'\0' * (align(len(buf), s['align']) - len(buf)))
            layout[s['i']] = (name, len(buf))
            buf.extend(d[s['off']:s['off'] + s['size']])
        raw = len(buf)
        vsize = raw
        if extra_bss:
            for s in extra_bss:
                vsize = align(vsize, s['align'])
                layout[s['i']] = (name, vsize)
                vsize += s['size']
        if vsize == 0: return
        pe_secs[name] = dict(rva=cur_rva, vsize=vsize, data=buf, chars=chars)
        cur_rva = align(cur_rva + vsize, SEC_ALIGN)
    build('.text', groups['.text'], 0x60000020)
    build('.rdata', groups['.rdata'], 0x40000040)
    build('.data', groups['.data'], 0xC0000040, extra_bss=groups['.bss'])

    def sec_rva(shndx):
        nm, off = layout[shndx]
        return pe_secs[nm]['rva'] + off
    def sym_va(s):
        if s['shndx'] == 0xfff1: return s['value']
        if s['shndx'] == 0: raise SystemExit('UNDEFINED SYMBOL: %s' % s['name'])
        if s['shndx'] == 0xfff2: raise SystemExit('COMMON symbol (use -fno-common): %s' % s['name'])
        return IMAGE_BASE + sec_rva(s['shndx']) + s['value']

    # ---- apply relocations
    base_relocs = []
    for rs in secs:
        if rs['type'] != 9: continue
        tgt = rs['info']
        if tgt not in layout: continue          # relocs for non-alloc sections (debug) ignored
        nm, base_off = layout[tgt]
        buf = pe_secs[nm]['data']
        for k in range(rs['size'] // 8):
            r_off, r_info = struct.unpack_from('<II', d, rs['off'] + k * 8)
            rtype, rsym = r_info & 0xff, r_info >> 8
            S = sym_va(syms[rsym])
            pos = base_off + r_off
            A, = struct.unpack_from('<i', buf, pos)
            P = IMAGE_BASE + pe_secs[nm]['rva'] + pos
            if rtype == 1:      # R_386_32
                struct.pack_into('<I', buf, pos, (S + A) & 0xffffffff)
                base_relocs.append(P - IMAGE_BASE)
            elif rtype in (2, 4):   # PC32 / PLT32
                struct.pack_into('<I', buf, pos, (S + A - P) & 0xffffffff)
            else:
                raise SystemExit('unsupported reloc type %d in %s' % (rtype, rs['name']))

    # ---- entry + exports
    gsyms = {s['name']: s for s in syms if s['bind'] in (1, 2) and s['shndx'] not in (0,)}
    entry_rva = sym_va(gsyms[entry]) - IMAGE_BASE
    exp_items = sorted((x, sym_va(gsyms[x]) - IMAGE_BASE) for x in exports)

    # .edata
    edata = bytearray()
    ed_rva = cur_rva
    n = len(exp_items)
    hdr_size = 40
    addr_funcs = hdr_size
    addr_names = addr_funcs + 4 * n
    addr_ords = addr_names + 4 * n
    strs_off = addr_ords + 2 * n
    strings = bytearray()
    dll_name_off = strs_off
    strings += dllname.encode() + b'\0'
    name_offs = []
    for nm, _ in exp_items:
        name_offs.append(strs_off + len(strings)); strings += nm.encode() + b'\0'
    edata += struct.pack('<IIHHIIIIIII', 0, int(time.time()), 0, 0, ed_rva + dll_name_off, 1, n, n,
                         ed_rva + addr_funcs, ed_rva + addr_names, ed_rva + addr_ords)
    for _, r in exp_items: edata += struct.pack('<I', r)
    for o in name_offs: edata += struct.pack('<I', ed_rva + o)
    for k in range(n): edata += struct.pack('<H', k)
    edata += strings
    pe_secs['.edata'] = dict(rva=ed_rva, vsize=len(edata), data=edata, chars=0x40000040)
    cur_rva = align(ed_rva + len(edata), SEC_ALIGN)

    # .reloc
    pages = {}
    for r in sorted(set(base_relocs)):
        pages.setdefault(r & ~0xfff, []).append(r & 0xfff)
    reloc = bytearray()
    for page, offs in sorted(pages.items()):
        ents = [(3 << 12) | o for o in offs]
        if len(ents) % 2: ents.append(0)
        reloc += struct.pack('<II', page, 8 + 2 * len(ents))
        for e in ents: reloc += struct.pack('<H', e)
    if not reloc:  # keep a valid (empty-ish) block
        reloc += struct.pack('<II', 0, 8)
    rl_rva = cur_rva
    pe_secs['.reloc'] = dict(rva=rl_rva, vsize=len(reloc), data=reloc, chars=0x42000040)
    cur_rva = align(rl_rva + len(reloc), SEC_ALIGN)
    size_of_image = cur_rva

    # ---- file layout
    order = ['.text', '.rdata', '.data', '.edata', '.reloc']
    order = [o for o in order if o in pe_secs]
    file_off = HDR_SIZE
    for nm in order:
        p = pe_secs[nm]
        p['raw'] = bytes(p['data'])
        p['rawsize'] = align(len(p['raw']), FILE_ALIGN) if p['raw'] else 0
        p['fileoff'] = file_off if p['rawsize'] else 0
        file_off += p['rawsize']
        if not p['rawsize'] and nm == '.data': p['chars'] = 0xC0000080   # uninitialized data, RW

    code = pe_secs['.text']
    size_code = align(code['vsize'], FILE_ALIGN)
    size_init = sum(pe_secs[n_]['rawsize'] for n_ in order if n_ != '.text')
    bss_extra = 0
    if '.data' in pe_secs:
        bss_extra = max(0, align(pe_secs['.data']['vsize'], FILE_ALIGN) - pe_secs['.data']['rawsize'])
    base_of_data = pe_secs['.rdata']['rva'] if '.rdata' in pe_secs else 0

    dos = bytearray(0x80)
    dos[0:2] = b'MZ'
    struct.pack_into('<I', dos, 0x3c, 0x80)
    pe = bytearray()
    pe += b'PE\0\0'
    pe += struct.pack('<HHIIIHH', 0x14c, len(order), int(time.time()), 0, 0, 0xE0, 0x2102)
    opt = struct.pack('<HBBIIIIIIIIIHHHHHHIIIIHHIIIIII',
                      0x10b, 6, 0, size_code, size_init, bss_extra, entry_rva, code['rva'], base_of_data,
                      IMAGE_BASE, SEC_ALIGN, FILE_ALIGN,
                      5, 1, 0, 0, 5, 1, 0, size_of_image, HDR_SIZE, 0, 2, 0x0140,
                      0x100000, 0x1000, 0x100000, 0x1000, 0, 16)
    # struct above mixes widths; rebuild explicitly for clarity
    opt = bytearray()
    opt += struct.pack('<H', 0x10b)
    opt += struct.pack('<BB', 6, 0)
    opt += struct.pack('<III', size_code, size_init, bss_extra)
    opt += struct.pack('<III', entry_rva, code['rva'], base_of_data)
    opt += struct.pack('<III', IMAGE_BASE, SEC_ALIGN, FILE_ALIGN)
    opt += struct.pack('<HHHHHH', 5, 1, 0, 0, 5, 1)
    opt += struct.pack('<IIII', 0, size_of_image, HDR_SIZE, 0)
    opt += struct.pack('<HH', 2, 0x0140)
    opt += struct.pack('<IIII', 0x100000, 0x1000, 0x100000, 0x1000)
    opt += struct.pack('<II', 0, 16)
    dirs = [(0, 0)] * 16
    dirs[0] = (ed_rva, len(edata))
    dirs[5] = (rl_rva, len(reloc))
    for rva, sz in dirs: opt += struct.pack('<II', rva, sz)
    assert len(opt) == 0xE0, len(opt)
    pe += opt
    for nm in order:
        p = pe_secs[nm]
        pe += struct.pack('<8sIIIIIIHHI', nm.encode(), p['vsize'], p['rva'], p['rawsize'], p['fileoff'], 0, 0, 0, 0, p['chars'])
    hdr = bytes(dos) + bytes(pe)
    assert len(hdr) <= HDR_SIZE
    out = bytearray(hdr + b'\0' * (HDR_SIZE - len(hdr)))
    for nm in order:
        p = pe_secs[nm]
        out += p['raw'] + b'\0' * (p['rawsize'] - len(p['raw']))
    open(outp, 'wb').write(out)
    print('OK %s: %d bytes, image 0x%x, entry 0x%x, relocs %d, exports %s' % (outp, len(out), size_of_image, entry_rva, len(base_relocs), [x for x, _ in exp_items]))

main()
