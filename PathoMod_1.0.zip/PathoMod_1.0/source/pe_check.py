import struct, sys
d=open(sys.argv[1],'rb').read()
e=struct.unpack_from('<I',d,0x3c)[0]
nsec=struct.unpack_from('<H',d,e+6)[0]; osz=struct.unpack_from('<H',d,e+20)[0]
base=struct.unpack_from('<I',d,e+24+28)[0]; soi=struct.unpack_from('<I',d,e+24+56)[0]
secs=[]
for i in range(nsec):
    nm,vs,va,rs,ro=struct.unpack_from('<8sIIII',d,e+24+osz+i*40); secs.append((nm.rstrip(b'\0').decode(),va,vs,ro,rs))
def rva2off(r):
    for n,va,vs,ro,rs in secs:
        if va<=r<va+max(vs,rs) and r-va<rs: return ro+(r-va)
prev=0x1000
for n,va,vs,ro,rs in secs:
    assert va>=prev and ro%0x200==0 and rs%0x200==0, n
    prev=(va+vs+0xfff)//0x1000*0x1000
assert prev==soi and soi%0x1000==0
rr,rsz=struct.unpack_from('<II',d,e+24+96+5*8)
off=rva2off(rr); end=off+rsz; relocs=[]
while off<end:
    page,bsz=struct.unpack_from('<II',d,off)
    for k in range((bsz-8)//2):
        w=struct.unpack_from('<H',d,off+8+2*k)[0]
        if w>>12==3: relocs.append(page+(w&0xfff))
        else: assert w>>12==0
    off+=bsz
bad=0
for r in relocs:
    o=rva2off(r)
    if o is None: bad+=1; continue
    v=struct.unpack_from('<I',d,o)[0]
    if not (base<=v<base+soi): bad+=1
ex_rva,ex_sz=struct.unpack_from('<II',d,e+24+96); eo=rva2off(ex_rva)
nf,nn,af,an,ao=struct.unpack_from('<IIIII',d,eo+20); o=rva2off(struct.unpack_from('<I',d,rva2off(an))[0])
print('PE OK: image 0x%x, %d relocs (%d bad), export %s, sections %s'%(soi,len(relocs),bad,d[o:d.index(b"\0",o)].decode(),[s[0] for s in secs]))
assert bad==0
