/* core.h - PathoMod stage 1 diagnostics (platform independent).
 * The including file must provide: p_read, p_next_region, p_flush, p_tick
 * and set g_modbase[] / g_modsize[] before calling pm_dump().
 */
typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;
typedef int i32;

static int  p_read(u32 addr, void *dst, u32 len);          /* safe read of target memory   */
static int  p_next_region(u32 *cursor, u32 *base, u32 *size); /* next RW private region     */
static void p_flush(void);                                  /* write g_log to disk, reset  */
static u32  p_tick(void);                                   /* milliseconds                */
static void p_extra(void);                                  /* platform-specific report part */
/* includer must define PM_TAN(x) and PM_SQRT(x) (float) before including this file */

#include "tables.h"

#define LOGSZ 32768
#define MAXC 2048
#define MAXI 24000
#define NSTR 40

static char g_log[LOGSZ];
static u32 g_logn;

static void lc(char c) { if (g_logn >= LOGSZ - 1) p_flush(); g_log[g_logn++] = c; }
static void ls(const char *s) { while (*s) lc(*s++); }
static void lnl(void) { lc('\n'); }
static void lhex(u32 v, int d) {
    static const char H[] = "0123456789abcdef";
    for (int i = d - 1; i >= 0; i--) lc(H[(v >> (i * 4)) & 15]);
}
static void ldec(u32 v) {
    char t[12]; int n = 0;
    if (!v) { lc('0'); return; }
    while (v) { t[n++] = (char)('0' + v % 10); v /= 10; }
    while (n) lc(t[--n]);
}
static void lfloat(float f) {
    if (f < 0) { lc('-'); f = -f; }
    u32 ip = (u32)f; ldec(ip); lc('.');
    u32 fr = (u32)((f - (float)ip) * 1000.0f + 0.5f); if (fr > 999) fr = 999;
    lc((char)('0' + fr / 100)); lc((char)('0' + (fr / 10) % 10)); lc((char)('0' + fr % 10));
}
static int plausible_float(u32 b) {
    u32 e = (b >> 23) & 0xff;
    return e >= 0x6c && e <= 0x95;       /* ~1e-6 .. ~4e6 */
}

static int str_eq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static int str_pre(const char *s, const char *p) { while (*p) { if (*s++ != *p++) return 0; } return 1; }
static int str_has(const char *s, char c) { while (*s) if (*s++ == c) return 1; return 0; }
static int str_in(const char *s, const char *sub) {
    for (; *s; s++) { const char *a = s, *b = sub; while (*b && *a == *b) { a++; b++; } if (!*b) return 1; }
    return 0;
}

/* ---------------- module / vtable tables ---------------- */
static u32 g_modbase[3], g_modsize[3];      /* 0 = Game.exe, 1 = Engine.dll, 2 = D3D.dll */
static const u32 *g_vt[2] = { gvt, evt };
static const u32 g_nvt[2] = { NGVT, NEVT };

static int vt_find(const u32 *t, u32 n, u32 key) {
    u32 lo = 0, hi = n;
    while (lo < hi) { u32 m = (lo + hi) >> 1; if (t[m] < key) lo = m + 1; else hi = m; }
    return (lo < n && t[lo] == key) ? (int)lo : -1;
}

/* ---------------- RTTI ---------------- */
static int rtti_name(u32 vptr, char *out, int max, u32 *thisoff) {
    u32 col, w[5];
    char nm[72];
    int n;
    if (vptr < 0x10000 || !p_read(vptr - 4, &col, 4) || col < 0x10000) return 0;
    if (!p_read(col, w, 20) || w[0] != 0 || w[3] < 0x10000) return 0;
    if (!p_read(w[3] + 8, nm, 64)) {
        for (n = 0; n < 64; n++) { if (!p_read(w[3] + 8 + n, &nm[n], 1)) return 0; if (!nm[n]) break; }
    }
    nm[63] = 0;
    for (n = 0; nm[n]; n++) {}
    if (n < 5 || nm[0] != '.' || nm[1] != '?' || nm[2] != 'A') return 0;
    int e = n; if (e >= 2 && nm[e - 1] == '@' && nm[e - 2] == '@') e -= 2;
    int k = 0; for (int i = 4; i < e && k < max - 1; i++) out[k++] = nm[i];
    out[k] = 0;
    if (thisoff) *thisoff = w[1];
    return 1;
}

/* class name pool (resolved lazily) */
static char g_pool[131072]; static u32 g_pooln;
static u32 g_noff[2 * MAXC];
static const char *cls_name(u32 cid) {
    u32 m = cid / MAXC, idx = cid % MAXC;
    if (g_noff[cid]) return g_pool + g_noff[cid];
    char tmp[NSTR * 2];
    u32 vptr = g_modbase[m] + g_vt[m][idx];
    if (!rtti_name(vptr, tmp, sizeof tmp, 0)) { tmp[0] = '?'; tmp[1] = 0; }
    u32 l = 0; while (tmp[l]) l++;
    if (g_pooln + l + 2 >= sizeof g_pool) return "(pool full)";
    if (g_pooln == 0) g_pooln = 1;
    g_noff[cid] = g_pooln;
    for (u32 i = 0; i <= l; i++) g_pool[g_pooln++] = tmp[i];
    return g_pool + g_noff[cid];
}

/* ---------------- census ---------------- */
static u32 g_cnt[2 * MAXC];
static u32 g_iaddr[MAXI];
static u16 g_icid[MAXI];
static u32 g_ni, g_nover;
static u32 g_regions, g_bytes;
static u8 g_buf[1 << 20] __attribute__((aligned(16)));

/* actor kinds that implement IPlayerUsable */
#define NK 11
static const char *const K_NAME[NK] = { "CActorBiped", "CActorBipedCol", "CActorBipedLSH", "CActorDoor", "CActorObject",
    "CActorScripted", "CActorScriptedCol", "CActorScriptedContainer", "CActorStatic", "CActorStaticIndoor", "CActorStaticOutdoor" };
static const u16 K_FLAG[NK] = { 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xD8, 0x11A, 0x11A, 0x11A, 0x105, 0x105, 0x105 };
static const u8  K_GRP[NK]  = { 0, 0, 0, 1, 2, 2, 2, 2, 3, 3, 3 };          /* 0 npc, 1 door, 2 object, 3 static */
static const u16 K_POSDEF[NK] = { 0x170, 0x170, 0x170, 0, 0, 0, 0, 0, 0x108, 0x108, 0x108 };
static const float K_YOFF[NK] = { 100.0f, 100.0f, 100.0f, 0, 0, 0, 0, 0, 0, 0, 0 };   /* marker height above the stored point */
static u16 g_posoff[NK];               /* known/learned position offset per kind (0 = unknown) */
static u8  g_ev[NK][0xC0 + 1];         /* evidence: hits per offset/4 */
static u8  g_kind[2 * MAXC];           /* kind+1 for actor classes */
static u32 g_lim[2 * MAXC];            /* how many instances to store (0xFFFFFFFF = all) */
static u32 g_stored[2 * MAXC];
static int g_policy_ready;
static const char *cls_name(u32 cid);
static int is_interest(const char *n);

static void prep_policy(void) {
    if (g_policy_ready) return;
    for (int m = 0; m < 2; m++) {
        if (!g_modbase[m]) continue;
        for (u32 idx = 0; idx < g_nvt[m]; idx++) {
            u32 cid = (u32)m * MAXC + idx;
            const char *n = cls_name(cid);
            for (int k = 0; k < NK; k++) if (m == 0 && str_eq(n, K_NAME[k])) { g_kind[cid] = (u8)(k + 1); g_lim[cid] = 0xFFFFFFFFu; }
            if (!g_lim[cid] && (is_interest(n) || str_pre(n, "CCamera"))) g_lim[cid] = 8;
            if (str_eq(n, "CActorData@CWorld")) g_lim[cid] = 4;
        }
    }
    for (int k = 0; k < NK; k++) g_posoff[k] = K_POSDEF[k];
    g_policy_ready = 1;
}

/* ---- incremental (time-sliced) census with "hot region" cache ---- */
#define MAXHOT 256
static u32 g_hot_b[MAXHOT], g_hot_s[MAXHOT], g_nhot, g_hot_valid;     /* regions that held actors in the last full scan */
static u32 g_new_b[MAXHOT], g_new_s[MAXHOT], g_nnew;
static int g_sc_state, g_sc_mode, g_sc_inreg;                         /* state: 0 idle, 1 running; mode: 0 full, 1 hot-only */
static u32 g_sc_cur, g_sc_rb, g_sc_rs, g_sc_off, g_sc_hi, g_sc_t0;
static u32 g_rb_cur, g_rs_cur;

static void hot_mark(void) {
    if (g_sc_mode != 0) return;
    if (g_nnew && g_new_b[g_nnew - 1] == g_rb_cur) return;          /* regions are visited in ascending order */
    if (g_nnew < MAXHOT) { g_new_b[g_nnew] = g_rb_cur; g_new_s[g_nnew] = g_rs_cur; g_nnew++; }
    else g_nnew = MAXHOT + 1;                                        /* overflow marker: hot list unusable */
}

static void scan_words(u32 base, u32 n) {
    const u32 *w = (const u32 *)g_buf;
    u32 cnt = n >> 2;
    for (u32 i = 0; i < cnt; i++) {
        u32 v = w[i], rel;
        int m;
        if ((rel = v - g_modbase[0]) < g_modsize[0]) m = 0;
        else if ((rel = v - g_modbase[1]) < g_modsize[1]) m = 1;
        else continue;
        int idx = vt_find(g_vt[m], g_nvt[m], rel);
        if (idx < 0) continue;
        u32 cid = (u32)m * MAXC + (u32)idx;
        g_cnt[cid]++;
        if (g_lim[cid] && g_stored[cid] < g_lim[cid]) {
            if (g_ni < MAXI) { g_iaddr[g_ni] = base + (i << 2); g_icid[g_ni] = (u16)cid; g_ni++; g_stored[cid]++; hot_mark(); }
            else g_nover++;
        }
    }
}

static void scan_begin(int mode) {
    prep_policy();
    g_ni = g_nover = g_regions = g_bytes = 0;
    for (u32 i = 0; i < 2 * MAXC; i++) { g_cnt[i] = 0; g_stored[i] = 0; }
    g_sc_cur = 0x10000; g_sc_inreg = 0; g_sc_mode = mode; g_sc_hi = 0; g_nnew = 0;
    g_sc_state = 1; g_sc_t0 = p_tick();
}

static void scan_finish(void) {
    if (g_sc_mode == 0) {
        g_hot_valid = (g_nnew <= MAXHOT);
        if (g_hot_valid) { for (u32 i = 0; i < g_nnew; i++) { g_hot_b[i] = g_new_b[i]; g_hot_s[i] = g_new_s[i]; } g_nhot = g_nnew; }
    }
    g_sc_state = 0; g_sc_inreg = 0;
}

/* process up to `budget` bytes; returns 1 when the census is complete */
static int scan_step(u32 budget) {
    while (g_sc_state == 1) {
        if (!g_sc_inreg) {
            if (g_sc_mode == 0) { if (!p_next_region(&g_sc_cur, &g_sc_rb, &g_sc_rs)) { scan_finish(); return 1; } }
            else {
                if (g_sc_hi >= g_nhot) { scan_finish(); return 1; }
                g_sc_rb = g_hot_b[g_sc_hi]; g_sc_rs = g_hot_s[g_sc_hi]; g_sc_hi++;
            }
            g_sc_off = 0; g_sc_inreg = 1; g_regions++;
        }
        if (budget == 0) return 0;
        u32 n = g_sc_rs - g_sc_off;
        if (n > sizeof g_buf) n = sizeof g_buf;
        if (n > budget) n = budget;
        n &= ~3u; if (!n) n = 4;
        g_rb_cur = g_sc_rb; g_rs_cur = g_sc_rs;
        if (p_read(g_sc_rb + g_sc_off, g_buf, n)) { scan_words(g_sc_rb + g_sc_off, n); g_bytes += n; }
        else {   /* partly unreadable: go page by page */
            for (u32 p = 0; p < n; p += 4096) {
                u32 pn = n - p; if (pn > 4096) pn = 4096;
                if (p_read(g_sc_rb + g_sc_off + p, g_buf, pn)) { scan_words(g_sc_rb + g_sc_off + p, pn); g_bytes += pn; }
            }
        }
        g_sc_off += n;
        budget = budget > n ? budget - n : 0;
        if (g_sc_off >= g_sc_rs) g_sc_inreg = 0;
    }
    return 1;
}

/* synchronous census (used by the F8 diagnostic dump) */
static void census(void) {
    scan_begin(0);
    while (!scan_step(0xFFFFFFFFu)) {}
}

/* ---------------- usable flag (IPlayerUsable::slot4 implementations) ----------------
 * returns 1/0 for field-backed flags, 2 for classes whose method is a constant 'true', -1 unknown */
static int usable_flag(const char *n, u32 a) {
    u32 off;
    if (str_eq(n, "CActorStatic") || str_eq(n, "CActorStaticIndoor") || str_eq(n, "CActorStaticOutdoor")) off = 0x2C + 0xD9;
    else if (str_eq(n, "CActorObject")) off = 0xA4 + 0x34;
    else if (str_eq(n, "CActorScripted") || str_eq(n, "CActorScriptedCol") || str_eq(n, "CActorScriptedContainer")) off = 0xCC + 0x4E;
    else if (str_eq(n, "CActorDoor") || str_eq(n, "CActorBiped") || str_eq(n, "CActorBipedCol") || str_eq(n, "CActorBipedLSH")) return 2;
    else return -1;
    u8 b;
    if (!p_read(a + off, &b, 1)) return -1;
    return b ? 1 : 0;
}

static int is_actor(const char *n) { return str_pre(n, "CActor") && !str_has(n, '@'); }

static int is_interest(const char *n) {
    static const char *const L[] = {
        "CCPPlayer", "CActorPlayer", "CCameraPlay", "CCameraBase", "CCameraAttached", "CCameraFloat",
        "CCameraMotion", "CCameraTransit", "CCameraWideScr", "CGameCameraBase", "CGameSceneBase",
        "CGameSceneIndoor", "CGameSceneOutdoor", "CGameServices", "CGameWorld", "CWorld", "CEngine",
        "CSceneManager", "CSceneOutdoor", "CSceneIndoor", "CCameraSnapshot", "CCameraSnapshotAttached", "CActorData@CWorld", 0 };
    for (int i = 0; L[i]; i++) if (str_eq(n, L[i])) return 1;
    return 0;
}


/* ---------------- camera, world, highlight list, projection ---------------- */
typedef struct { float pos[3], fwd[3], up[3], fov; } Cam;
static u32 g_s_player, g_s_world, g_s_snap, g_world_vptr, g_scene;
static float g_pp[3]; static int g_pp_ok;
static u32 g_W, g_H;

static float fabsf_(float f) { return f < 0 ? -f : f; }
static int fl_ok(float f) { return f > -1e7f && f < 1e7f; }

static int cam_valid(Cam *c) {
    for (int i = 0; i < 3; i++) if (!fl_ok(c->pos[i]) || !fl_ok(c->fwd[i]) || !fl_ok(c->up[i])) return 0;
    float l = c->fwd[0] * c->fwd[0] + c->fwd[1] * c->fwd[1] + c->fwd[2] * c->fwd[2];
    if (l < 0.8f || l > 1.2f) return 0;
    return c->fov > 0.2f && c->fov < 3.0f;
}
/* engine camera snapshot (CCameraSnapshot*): fov +0x14, pos +0x20, fwd +0x2C, up +0x38 */
static int read_cam(u32 a, Cam *c) {
    u8 b[0x48];
    if (!a || !p_read(a, b, sizeof b)) return 0;
    const float *f = (const float *)b;
    c->fov = f[0x14 / 4];
    for (int i = 0; i < 3; i++) { c->pos[i] = f[0x20 / 4 + i]; c->fwd[i] = f[0x2C / 4 + i]; c->up[i] = f[0x38 / 4 + i]; }
    return cam_valid(c);
}
/* game camera (CCameraAttached, pointed to by CWorld+0x64): fov +0x24, pos +0x44, fwd +0x5C, up +0x68 */
static int read_cam_game(u32 a, Cam *c) {
    u8 b[0x78];
    if (!a || !p_read(a, b, sizeof b)) return 0;
    const float *f = (const float *)b;
    c->fov = f[0x24 / 4];
    for (int i = 0; i < 3; i++) { c->pos[i] = f[0x44 / 4 + i]; c->fwd[i] = f[0x5C / 4 + i]; c->up[i] = f[0x68 / 4 + i]; }
    return cam_valid(c);
}
static int get_camera(Cam *c) {
    u32 cp = 0;
    if (g_s_world && p_read(g_s_world + 0x64, &cp, 4) && cp && read_cam_game(cp, c)) return 1;
    return read_cam(g_s_snap, c);
}

/* mode 0: fov horizontal; 1: fov vertical; 2: vertical, fixed 4:3; 3: EXACT (measured from the game's own matrix):
 * tan(vfov/2) = tan(fov/2) * 0.75, tan(hfov/2) = tan(vfov/2) * W/H  */
static int project(const Cam *c, const float *p, float W, float H, int mode, int mirror, float *sx, float *sy, float *vzo) {
    float dx = p[0] - c->pos[0], dy = p[1] - c->pos[1], dz = p[2] - c->pos[2];
    float rx = c->up[1] * c->fwd[2] - c->up[2] * c->fwd[1];
    float ry = c->up[2] * c->fwd[0] - c->up[0] * c->fwd[2];
    float rz = c->up[0] * c->fwd[1] - c->up[1] * c->fwd[0];
    float rl = PM_SQRT(rx * rx + ry * ry + rz * rz);
    if (rl < 1e-4f) return 0;
    rx /= rl; ry /= rl; rz /= rl;
    if (mirror) { rx = -rx; ry = -ry; rz = -rz; }
    float vx = dx * rx + dy * ry + dz * rz;
    float vy = dx * c->up[0] + dy * c->up[1] + dz * c->up[2];
    float vz = dx * c->fwd[0] + dy * c->fwd[1] + dz * c->fwd[2];
    if (vz < 5.0f) return 0;
    float t = PM_TAN(c->fov * 0.5f), tx, ty;
    if (mode == 0) { tx = t; ty = t * H / W; }
    else if (mode == 1) { ty = t; tx = t * W / H; }
    else if (mode == 2) { ty = t; tx = t * (4.0f / 3.0f); }
    else { ty = t * 0.75f; tx = ty * W / H; }
    *sx = W * 0.5f * (1.0f + vx / (vz * tx));
    *sy = H * 0.5f * (1.0f - vy / (vz * ty));
    *vzo = vz;
    return 1;
}

/* depth-buffer value (0..1) of a point at view depth vz, near=10, far=20010 (verified against the game matrix) */
static float proj_z(float vz) {
    const float n = 10.0f, f = 20010.0f;
    if (vz <= n) return 0.0f;
    float z = (f / (f - n)) * (1.0f - n / vz);
    return z < 0.0f ? 0.0f : (z > 1.0f ? 1.0f : z);
}

static void lvec(const float *v) {
    lc('('); lfloat(v[0]); ls(", "); lfloat(v[1]); ls(", "); lfloat(v[2]); lc(')');
}

static void find_specials(void) {
    g_s_player = g_s_world = g_s_snap = g_world_vptr = g_scene = 0; g_pp_ok = 0;
    u32 snap_any = 0;
    for (u32 i = 0; i < g_ni; i++) {
        u32 cid = g_icid[i];
        const char *n = cls_name(cid);
        if (!g_s_player && cid < MAXC && str_eq(n, "CActorPlayer")) g_s_player = g_iaddr[i];
        else if (!g_s_world && cid >= MAXC && str_eq(n, "CWorld")) { g_s_world = g_iaddr[i]; g_world_vptr = g_modbase[1] + evt[cid - MAXC]; }
        else if (cid >= MAXC && str_eq(n, "CCameraSnapshotAttached") && !g_s_snap) g_s_snap = g_iaddr[i];
        else if (cid >= MAXC && str_pre(n, "CCameraSnapshot") && !snap_any) snap_any = g_iaddr[i];
    }
    if (!g_s_snap) g_s_snap = snap_any;
    if (g_s_world) p_read(g_s_world + 0x38, &g_scene, 4);
    Cam c;
    if (get_camera(&c)) { g_pp[0] = c.pos[0]; g_pp[1] = c.pos[1]; g_pp[2] = c.pos[2]; g_pp_ok = 1; }
    else if (g_s_player && p_read(g_s_player + 0x98, g_pp, 12)) g_pp_ok = 1;
}
static int world_valid(void) {
    u32 vp;
    return g_s_world && p_read(g_s_world, &vp, 4) && vp == g_world_vptr;
}
static u32 scene_now(void) { u32 s = 0; if (g_s_world) p_read(g_s_world + 0x38, &s, 4); return s; }

/* ---- highlight entries: usable actors of the ACTIVE scene ---- */
#define MAXHL 3000
typedef struct { u32 addr, vptr; float pos[3]; u16 posoff, flagoff; u8 kc, grp, usable, valid; } HLE;
static HLE g_hl[MAXHL];
static u32 g_nhl;

static void hl_refresh(HLE *e) {
    u32 vp; u8 f = 1; float p[3];
    e->valid = 0;
    if (!p_read(e->addr, &vp, 4) || vp != e->vptr) return;
    if (e->flagoff != 0xFFFF && !p_read(e->addr + e->flagoff, &f, 1)) return;
    e->usable = f != 0;
    if (!e->posoff || !p_read(e->addr + e->posoff, p, 12)) return;
    if (!fl_ok(p[0]) || !fl_ok(p[1]) || !fl_ok(p[2])) return;
    e->pos[0] = p[0]; e->pos[1] = p[1] + K_YOFF[e->kc]; e->pos[2] = p[2];
    e->valid = 1;
}

/* position offsets are learned from actors standing close to the camera */
static void learn_offsets(void) {
    Cam cam; u8 blk[0x300]; u32 done[NK];
    if (!get_camera(&cam)) return;
    for (int k = 0; k < NK; k++) done[k] = 0;
    for (u32 i = 0; i < g_nhl; i++) {
        u8 kc = g_hl[i].kc;
        if (done[kc] >= 60) continue;
        if (!p_read(g_hl[i].addr, blk, sizeof blk)) continue;
        done[kc]++;
        const float *f = (const float *)blk;
        for (u32 o = 0; o + 12 <= sizeof blk && o / 4 <= 0xC0; o += 4) {
            float x = f[o / 4], y = f[o / 4 + 1], z = f[o / 4 + 2];
            if (!fl_ok(x) || !fl_ok(y) || !fl_ok(z)) continue;
            if (fabsf_(x) < 2.0f || fabsf_(z) < 2.0f) continue;
            if (fabsf_(x - cam.pos[0]) < 900.0f && fabsf_(y - cam.pos[1]) < 900.0f && fabsf_(z - cam.pos[2]) < 900.0f)
                if (g_ev[kc][o / 4] < 255) g_ev[kc][o / 4]++;
        }
    }
    for (int k = 0; k < NK; k++) {
        if (g_posoff[k]) continue;
        u32 best = 0, bo = 0;
        for (u32 q = 0; q <= 0xC0; q++) if (g_ev[k][q] > best) { best = g_ev[k][q]; bo = q * 4; }
        if (best >= 2) g_posoff[k] = (u16)bo;
    }
}

static void hl_build(void) {
    g_nhl = 0;
    if (!g_scene) return;
    for (u32 i = 0; i < g_ni && g_nhl < MAXHL; i++) {
        u32 cid = g_icid[i], sc = 0;
        if (!g_kind[cid]) continue;
        if (!p_read(g_iaddr[i] + 0x20, &sc, 4) || sc != g_scene) continue;       /* active scene only */
        u8 kc = (u8)(g_kind[cid] - 1);
        HLE *e = &g_hl[g_nhl++];
        e->addr = g_iaddr[i]; e->vptr = g_modbase[0] + gvt[cid]; e->kc = kc; e->grp = K_GRP[kc];
        e->flagoff = K_FLAG[kc]; e->posoff = 0; e->valid = 0; e->usable = 0;
    }
    learn_offsets();
    for (u32 i = 0; i < g_nhl; i++) { g_hl[i].posoff = g_posoff[g_hl[i].kc]; hl_refresh(&g_hl[i]); }
    /* drop flag-backed objects that are not usable right now (keeps per-frame work small) */
    u32 w = 0;
    for (u32 i = 0; i < g_nhl; i++) {
        if (g_hl[i].flagoff != 0xFFFF && !g_hl[i].usable) continue;
        if (w != i) g_hl[w] = g_hl[i];
        w++;
    }
    g_nhl = w;
}
/* called when markers are shown: learn more position offsets from what is near the camera now */
static void hl_relearn(void) {
    learn_offsets();
    for (u32 i = 0; i < g_nhl; i++) if (!g_hl[i].posoff && g_posoff[g_hl[i].kc]) { g_hl[i].posoff = g_posoff[g_hl[i].kc]; hl_refresh(&g_hl[i]); }
}

/* ---------------- configuration (pathomod.ini) ---------------- */
typedef struct { int hold_vk, latch_vk, depth_vk, show[4], depth, debug; float maxdist, size; } Cfg;
static Cfg g_cfg = { 0x09, 0x78, 0x2D, { 1, 1, 1, 1 }, 1, 0, 4000.0f, 13.0f };

static const char *ini_num(const char *p, int *out) {
    int v = 0, neg = 0, hex = 0;
    while (*p == ' ' || *p == '\t') p++;
    if (*p == '-') { neg = 1; p++; }
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) { hex = 1; p += 2; }
    int any = 0;
    for (;; p++) {
        int d;
        if (*p >= '0' && *p <= '9') d = *p - '0';
        else if (hex && *p >= 'a' && *p <= 'f') d = *p - 'a' + 10;
        else if (hex && *p >= 'A' && *p <= 'F') d = *p - 'A' + 10;
        else break;
        v = v * (hex ? 16 : 10) + d; any = 1;
    }
    if (!any) return 0;
    *out = neg ? -v : v;
    return p;
}
static void ini_apply(const char *buf, u32 len) {
    u32 i = 0;
    while (i < len) {
        while (i < len && (buf[i] == ' ' || buf[i] == '\t' || buf[i] == '\r' || buf[i] == '\n')) i++;
        char key[32]; u32 k = 0; int comment = (i < len && (buf[i] == ';' || buf[i] == '#' || buf[i] == '['));
        while (i < len && buf[i] != '=' && buf[i] != '\n') { if (!comment && k < 31 && buf[i] != ' ' && buf[i] != '\t' && buf[i] != '\r') key[k++] = buf[i]; i++; }
        key[k] = 0;
        if (comment || i >= len || buf[i] != '=') { while (i < len && buf[i] != '\n') i++; continue; }
        i++;
        char val[40]; u32 vl = 0;
        while (i < len && buf[i] != '\n' && buf[i] != ';' && buf[i] != '#') { if (vl < 39) val[vl++] = buf[i]; i++; }
        val[vl] = 0;
        while (i < len && buf[i] != '\n') i++;
        int v;
        if (!ini_num(val, &v)) continue;
        if (str_eq(key, "hold_key")) g_cfg.hold_vk = v;
        else if (str_eq(key, "latch_key")) g_cfg.latch_vk = v;
        else if (str_eq(key, "depth_key")) g_cfg.depth_vk = v;
        else if (str_eq(key, "max_distance_m")) { if (v >= 1 && v <= 1000) g_cfg.maxdist = (float)v * 100.0f; }
        else if (str_eq(key, "marker_size")) { if (v >= 4 && v <= 60) g_cfg.size = (float)v; }
        else if (str_eq(key, "depth_test")) g_cfg.depth = v != 0;
        else if (str_eq(key, "debug")) g_cfg.debug = v != 0;
        else if (str_eq(key, "show_npc")) g_cfg.show[0] = v != 0;
        else if (str_eq(key, "show_door")) g_cfg.show[1] = v != 0;
        else if (str_eq(key, "show_object")) g_cfg.show[2] = v != 0;
        else if (str_eq(key, "show_static")) g_cfg.show[3] = v != 0;
    }
}

/* ---------------- object dump ---------------- */
#define DUMPMAX 0x240
static void dump_obj(u32 a, u32 len) {
    u8 b[DUMPMAX];
    if (len > DUMPMAX) len = DUMPMAX;
    if (!p_read(a, b, len)) { ls("   (unreadable)\n"); return; }
    const u32 *w = (const u32 *)b;
    for (u32 o = 0; o < len; o += 16) {
        ls("   +"); lhex(o, 3); ls(": ");
        for (u32 j = 0; j < 4; j++) { lhex(w[(o >> 2) + j], 8); lc(' '); }
        ls("|");
        for (u32 j = 0; j < 4; j++) {
            u32 v = w[(o >> 2) + j]; lc(' ');
            if (plausible_float(v)) { float f; *(u32 *)&f = v; lfloat(f); } else lc('.');
        }
        lnl();
    }
    for (u32 o = 0; o < len; o += 4) {          /* pointers to polymorphic objects */
        u32 v = w[o >> 2], vp;
        if (v < 0x10000 || v >= 0x7FFF0000 || (v & 3)) continue;
        if (!p_read(v, &vp, 4)) continue;
        if ((vp - g_modbase[0]) >= g_modsize[0] && (vp - g_modbase[1]) >= g_modsize[1] &&
            (vp - g_modbase[2]) >= g_modsize[2]) continue;
        char nm[NSTR * 2]; u32 to;
        if (!rtti_name(vp, nm, sizeof nm, &to)) continue;
        ls("   ptr +"); lhex(o, 3); ls(" -> "); lhex(v, 8); ls(" : "); ls(nm);
        if (to) { ls(" (sub+"); ldec(to); ls(")"); }
        lnl();
    }
    if (g_pp_ok) {                                /* float triples near the player = position candidates */
        const float *f = (const float *)b;
        for (u32 o = 0; o + 12 <= len; o += 4) {
            float x = f[o / 4], y = f[o / 4 + 1], z = f[o / 4 + 2];
            if (!fl_ok(x) || !fl_ok(y) || !fl_ok(z)) continue;
            if (fabsf_(x) < 1.0f && fabsf_(z) < 1.0f) continue;
            float dx = x - g_pp[0], dy = y - g_pp[1], dz = z - g_pp[2];
            if (dx * dx + dz * dz < 9.0e6f && dy > -3000.0f && dy < 3000.0f) {
                ls("   poscand +"); lhex(o, 3); ls(" "); lvec(&f[o / 4]); lnl();
            }
        }
    }
}

/* ---------------- main report ---------------- */
static u32 g_dumpno, g_tmp32;
static int check_module(int i, u32 exp_ts, u32 exp_size) {
    u32 e, ts, sz;
    if (!g_modbase[i]) return 0;
    if (!p_read(g_modbase[i] + 0x3c, &e, 4) || !p_read(g_modbase[i] + e + 8, &ts, 4) || !p_read(g_modbase[i] + e + 24 + 56, &sz, 4)) return 0;
    return ts == exp_ts && sz == exp_size;
}

static void pm_dump(void) {
    u32 t0 = p_tick();
    g_dumpno++;
    ls("\n=============== PATHOMOD DUMP #"); ldec(g_dumpno); ls(" ===============\n");
    static const char *const mn[3] = { "Game.exe", "Engine.dll", "D3D.dll" };
    for (int i = 0; i < 3; i++) { ls(mn[i]); ls(" base=0x"); lhex(g_modbase[i], 8); ls(" size=0x"); lhex(g_modsize[i], 8); lnl(); }
    int ok0 = check_module(0, GAME_TS, GAME_SIZE), ok1 = check_module(1, ENG_TS, ENG_SIZE);
    ls("fingerprint Game.exe: "); ls(ok0 ? "OK" : "MISMATCH"); ls("  Engine.dll: "); ls(ok1 ? "OK" : "MISMATCH"); lnl();
    if (!ok0 || !ok1) { ls("tables do not match these binaries - census skipped\n"); p_flush(); return; }

    census();
    ls("scan: regions="); ldec(g_regions); ls(" MB="); ldec(g_bytes >> 20); ls(" instances="); ldec(g_ni);
    ls(" overflow="); ldec(g_nover); ls(" ms="); ldec(p_tick() - t0); lnl();

    find_specials();
    ls("\n--- SPECIALS ---\n");
    ls("window="); ldec(g_W); ls("x"); ldec(g_H); lnl();
    ls("player=0x"); lhex(g_s_player, 8);
    if (g_pp_ok) { ls(" ref(camera)pos="); lvec(g_pp); }
    lnl();
    ls("active scene="); lhex(g_scene, 8); lnl();
    ls("world=0x"); lhex(g_s_world, 8);
    if (g_s_world) { u32 sel = 0, camp = 0; p_read(g_s_world + 0x70, &sel, 4); p_read(g_s_world + 0x64, &camp, 4); ls(" selected(+0x70)=0x"); lhex(sel, 8); ls(" camera(+0x64)=0x"); lhex(camp, 8); }
    lnl();
    ls("camsnap=0x"); lhex(g_s_snap, 8);
    { Cam c; if (read_cam(g_s_snap, &c)) { ls(" snap-pos="); lvec(c.pos); } else ls(" (snapshot unreadable)"); }
    lnl();
    ls("camera(used)");
    { Cam c; if (get_camera(&c)) { ls(" fov="); lfloat(c.fov); ls(" pos="); lvec(c.pos); ls(" fwd="); lvec(c.fwd); ls(" up="); lvec(c.up); } else ls(" (unreadable)"); }
    lnl();

    ls("\n--- CLASS COUNTS (primary vtable hits) ---\n");
    for (u32 c = 0; c < 2 * MAXC; c++) if (g_cnt[c]) { ldec(g_cnt[c]); ls("\t"); ls(c >= MAXC ? "E:" : "G:"); ls(cls_name(c)); lnl(); }

    ls("\n--- ACTOR 'IsUsable' FLAGS (flag read from memory; 2 = method is constant true) ---\n");
    for (u32 c = 0; c < 2 * MAXC; c++) {
        if (!g_cnt[c]) continue;
        const char *n = cls_name(c);
        if (!is_actor(n)) continue;
        u32 f0 = 0, f1 = 0, f2 = 0, fu = 0;
        for (u32 i = 0; i < g_ni; i++) if (g_icid[i] == c) {
            int f = usable_flag(n, g_iaddr[i]);
            if (f == 0) f0++; else if (f == 1) f1++; else if (f == 2) f2++; else fu++;
        }
        ls(n); ls(": total="); ldec(g_cnt[c]); ls(" flag1="); ldec(f1); ls(" flag0="); ldec(f0);
        ls(" always="); ldec(f2); ls(" unknown="); ldec(fu); lnl();
    }

    ls("\n--- INSTANCES WITH flag==1 (max 25 per class) ---\n");
    for (u32 c = 0; c < 2 * MAXC; c++) {
        if (!g_cnt[c]) continue;
        const char *n = cls_name(c);
        if (!is_actor(n)) continue;
        u32 shown = 0;
        for (u32 i = 0; i < g_ni && shown < 25; i++) if (g_icid[i] == c && usable_flag(n, g_iaddr[i]) == 1 && (!g_scene || (p_read(g_iaddr[i] + 0x20, &g_tmp32, 4) && g_tmp32 == g_scene))) {
            if (!shown) { ls(n); ls(":"); }
            ls(" "); lhex(g_iaddr[i], 8); shown++;
        }
        if (shown) lnl();
    }

    ls("\n--- OBJECT DUMPS ---\n");
    for (u32 c = 0; c < 2 * MAXC; c++) {
        if (!g_cnt[c]) continue;
        const char *n = cls_name(c);
        int actor = is_actor(n);
        if (!actor && !is_interest(n) && !str_pre(n, "CCamera")) continue;
        u32 want_on = 2, want_off = actor ? 1 : 0, len = actor ? 0x240 : 0x180, shown_on = 0, shown_off = 0;
        if (str_eq(n, "CCPPlayer") || str_eq(n, "CActorPlayer")) want_on = 1;
        if (str_eq(n, "CActorData@CWorld")) { want_on = 4; len = 0x100; }
        for (u32 i = 0; i < g_ni; i++) {
            if (g_icid[i] != c) continue;
            if (actor && g_scene) { u32 sc = 0; if (!p_read(g_iaddr[i] + 0x20, &sc, 4) || sc != g_scene) continue; }
            int f = actor ? usable_flag(n, g_iaddr[i]) : 1;
            int on = (f != 0);
            if (on && shown_on >= want_on) continue;
            if (!on && shown_off >= want_off) continue;
            if (on) shown_on++; else shown_off++;
            ls("\n## "); ls(n); ls(" @ 0x"); lhex(g_iaddr[i], 8);
            if (actor) { ls("  usableflag="); if (f < 0) ls("?"); else ldec((u32)f); }
            lnl();
            dump_obj(g_iaddr[i], len);
            if (shown_on >= want_on && shown_off >= want_off) break;
        }
    }
    p_extra();
    ls("\n=============== END DUMP ===============\n");
    p_flush();
}
