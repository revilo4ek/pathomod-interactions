PathoMod 1.0 - interactive-object highlighter for Pathologic Classic HD (Steam)
==============================================================================

WHAT IT DOES
  While you hold the Tab key, markers are drawn over the game on every object you can
  interact with - similar to the Tab highlight in Fallout and other CRPGs.
    cyan diamond   - NPC
    orange         - door
    green          - item / object
    yellow         - the object you are currently looking at (selected by the game itself)
  Markers are hidden behind walls and shown within 40 m (configurable).

REQUIREMENTS
  * Pathologic Classic HD, Steam version, Windows, DirectX 9 (default renderer).
  * The mod is tied to a specific game build (see below). On a different build it draws
    nothing and shows THREE RED SQUARES in the top-left corner while the key is held.
  Verified build:
    Game.exe   4,971,008 bytes  SHA-256 541cc6b1c91609ea82a968a6ebc2b4f8051c7677babcc55dcb80d4a6b4ae75b9
    Engine.dll 2,525,184 bytes  SHA-256 5a9dca56aebf112713aec293038d786fb0fb9896a8c655130ce44dfb4ee97c6c
  Tested resolution: 1920x1080. The projection math is resolution-independent but other
  resolutions / aspect ratios have not been tested.

INSTALLATION
  1. In Steam: right-click the game -> Manage -> Browse local files.
  2. Find Game.exe (it may be in a subfolder) and copy d3d9.dll INTO THE SAME FOLDER.
  3. Launch the game through Steam, load into the world and hold Tab.
  The first display after launch or after a location change takes 1-2 seconds (a background
  scan runs; an amber square is shown in the corner). The game does not freeze.

UNINSTALL
  Delete d3d9.dll (and optionally pathomod.ini / pathomod_log.txt) from the Game.exe folder.
  To disable temporarily without deleting: create an empty file pathomod_off.txt next to
  Game.exe and restart the game.

CONTROLS (defaults)
  Tab (hold)  show markers
  F9          toggle markers on/off permanently
  Insert      toggle hiding markers behind walls
  All of these can be changed in pathomod.ini (created next to Game.exe on first launch).

SETTINGS (pathomod.ini; key codes are Windows virtual-key codes, decimal or 0x..)
  hold_key=0x09       show key (0x09 = Tab)
  latch_key=0x78      permanent toggle (0x78 = F9)
  depth_key=0x2D      wall-hiding toggle (0x2D = Insert)
  max_distance_m=40   maximum marker distance, meters
  marker_size=13      marker radius, pixels
  depth_test=1        1 = hide markers behind walls
  show_npc / show_door / show_object / show_static = 1 or 0
  debug=0             1 = developer keys and detailed logging
  Delete the file to restore defaults.

HOW IT WORKS (for the curious and for antivirus reviewers)
  d3d9.dll is a proxy: it loads the real system d3d9.dll and hooks Present to draw the
  markers. Object positions are READ from game memory (classes are identified through RTTI);
  game data and save files are not modified and no network access is used. The only memory
  that is modified is function pointers in the Direct3D vtable (that is the hook itself).
  A log is written to pathomod_log.txt (capped at 2 MB). Source code is in the source folder.

KNOWN LIMITATIONS
  * NPCs are always highlighted, even ones you cannot talk to (the game has no flag for them).
  * The marker sits on an object's anchor point; for large objects it may be off-center.
  * Objects spawned after a scan can take up to ~30 seconds to appear.
  * Incompatible with other d3d9.dll proxies (e.g. ReShade for DX9): same file name.
  * Unsigned hand-built DLL: some antivirus engines may raise a false positive.
    The file hash is in SHA256SUMS.txt; the source is open.

TROUBLESHOOTING
  * Three red squares: you have a different game build (see Requirements).
  * No markers and no squares: make sure d3d9.dll is next to Game.exe and check
    pathomod_log.txt (the first line should read "PathoMod 1.0 loaded").
  * Tab is used by something else in the game: change hold_key in pathomod.ini.

CREDITS AND LICENSE
  Unofficial mod, not affiliated with the developers or publishers of the game.
  Idea and testing: <YOUR NAME>. Code written with the help of the AI assistant Claude (Anthropic).
  License: MIT (see LICENSE.txt).
